
Balloons - v3 2022-01-01 4:56am
==============================

This dataset was exported via roboflow.ai on January 1, 2022 at 2:56 AM GMT

It includes 86 images.
Balloons are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 640x640 (Fit within)

No image augmentation techniques were applied.


